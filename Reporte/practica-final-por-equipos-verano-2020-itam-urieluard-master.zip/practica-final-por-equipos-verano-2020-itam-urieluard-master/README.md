# Consumo y Demanda de Energía en Sistemas de Potencia

Proyecto final del **Equipo 3**, integrado por:

|Integrante|User github|
|:--:|:--:|
|Antonio Huerta|[TheHornyDaddy](https://github.com/TheHornyDaddy)|
|Leonardo Ceja|[lecepe00](https://github.com/lecepe00)|
|Uriel Rangel*|[urieluard](https://github.com/urieluard)|

* Project Manager

Éste proyecto fue desarrollado en `Python`, con información proporcionada por el **Centro Nacional de Control de Energía (CENACE)**. 

Se trabajó con los datos de demanda y consumo de energía eléctrica de la Región Occidente de México, para el periodo Septiembre 2017 a Julio 2020.

